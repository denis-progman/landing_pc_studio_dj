<?php
const DATE_OF_PROJECT_START = "10/02/2023";
const MIN_USER_COUNT = 123;
const FILE_STORAGE = 'user_requests';
const USER_DELIMITER = "\n\n";
const FIELD_DELIMITER = "\n";
const KEY_DELIMITER = ":";
const LOG_FILE = "log";